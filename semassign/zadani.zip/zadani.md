Jako téma mé semestrální práce k předmětu byla zvolena implementace hry tetris na zařízení MicroZed APO.
Složení týmu:
	-Václav Fleissig (studentská zkratka fleisvac)
